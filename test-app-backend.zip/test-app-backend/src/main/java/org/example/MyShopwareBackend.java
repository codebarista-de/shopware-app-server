package org.example;

import de.codebarista.shopware.appserver.ShopwareApp;
import de.codebarista.shopware.appserver.api.dto.action.ActionRequestDto;
import de.codebarista.shopware.appserver.api.dto.action.ActionResponseDto;
import de.codebarista.shopware.appserver.api.dto.event.ShopwareEventDto;
import jakarta.annotation.Nonnull;
import jakarta.annotation.Nullable;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class MyShopwareBackend implements ShopwareApp {
    @Nonnull
    @Override
    public String getAppKey() {
        return "";
    }

    @Nonnull
    @Override
    public String getAppSecret() {
        return "";
    }

    @Nonnull
    @Override
    public String getAppName() {
        return "";
    }

    @Nullable
    @Override
    public String getVersion() {
        return "";
    }

    @Nullable
    @Override
    public String getAdminExtensionFolderName() {
        return "";
    }

    @Override
    public void onRegisterShop(@Nonnull String shopHost, @Nonnull String shopId, long internalShopId) {

    }

    @Override
    public void onReRegisterShop(@Nonnull String shopHost, @Nonnull String shopId, long internalShopId) {

    }

    @Override
    public void onDeleteShop(@Nonnull String shopHost, @Nonnull String shopId, long internalShopId) {

    }

    @Override
    public void onEvent(@Nonnull ShopwareEventDto event, long internalShopId, @Nullable Locale userLocale, @Nullable String shopwareLanguageId) {

    }

    @Nonnull
    @Override
    public ActionResponseDto<?> onAction(@Nonnull ActionRequestDto action, long internalShopId, @Nullable Locale userLocale, @Nullable String shopwareLanguageId) {
        return null;
    }
}
